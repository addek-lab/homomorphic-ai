"""M6: Hilft echter deutscher Text gegen Fehlalarme, und was bringt ein Hybrid aus Regeln und Modell?

Fortsetzung von M5 (experiment_routing.py). Dort hielt der gelernte Klassifikator bei unbekannten
Dokumentarten 93,5 % der harmlosen Zeilen zurück. Zwei Ideen werden hier geprüft:

  1. Echte harmlose deutsche Sätze im Training (Systemmeldungen aus Ubuntu-Übersetzungen und
     Fachtexte dieser Website, ohne Seiten mit Beispiel-Personendaten).
  2. Hybrid: Der Regelfilter läuft beim Client; das Modell gibt nur eine Zweitmeinung ab.
     Eine Zeile gilt als sensibel, wenn die Regeln ODER das Modell anschlagen.
     Die Schwelle des Modells wird nur auf den Trainingsarten gewählt (innere Kreuzvalidierung,
     jeweils eine Art weggelassen): so wenige Lecks wie möglich bei höchstens 10 % Fehlalarmen.

Bewertung wie M5-B: jede Dokumentart fehlt einmal im Training. Zusätzlich wird gemessen, wie viele
echte harmlose Sätze aus ANDEREN Quellen als im Training fälschlich gesperrt werden.

Aufruf:
  python experiment_hybrid.py --pruefstand ../pii-pruefstand --site .. \
      --mo-dir /usr/share/locale/de/LC_MESSAGES [--out ergebnisse/m6_hybrid.json]
"""
from __future__ import annotations

import argparse
import gettext
import html
import json
import os
import re
import statistics as st
import sys
import time
from collections import Counter

import numpy as np

from experiment_routing import N_DOCS, SEED_DOCS, segments, vectorizer, rates

MAX_FA_INNER = 0.10

# Echte harmlose Texte: Quellen für Training und Test sind getrennt.
MO_TRAIN = ["apt.mo", "dpkg.mo", "debconf.mo"]
MO_TEST = ["apt-utils.mo", "libapt-pkg6.0.mo", "zvbi.mo"]
SITE_TRAIN = ["knowledge.html", "blog/post-evidenz-bewerten.html", "blog/post-programmable-bootstrapping.html"]
SITE_TEST = ["labor.html", "blog/post-open-questions.html"]


def mo_lines(path):
    with open(path, "rb") as f:
        cat = gettext.GNUTranslations(f)._catalog
    out = []
    for k, v in cat.items():
        # Der Katalog-Kopf (leere msgid) enthält echte Namen und E-Mail-Adressen der Übersetzer:
        # das sind Personendaten und gehören weder als "harmlos" ins Training noch in die Ergebnisse.
        if k in ("", ("", 0)) or not isinstance(v, str):
            continue
        out += [l for l in v.split("\n") if "@" not in l]
    return out


def site_lines(path):
    t = open(path, encoding="utf-8").read()
    t = re.sub(r"(?s)<(script|style|header|footer|pre|code)\b.*?</\1>", " ", t)
    t = re.sub(r"<(br|/p|/li|/h\d|/div|/td|/dd|/dt)\b[^>]*>", "\n", t)
    t = html.unescape(re.sub(r"<[^>]+>", " ", t))
    out = []
    for block in t.split("\n"):
        out += re.split(r"(?<=[.!?:])\s+", re.sub(r"\s+", " ", block).strip())
    return out


def clean(lines, cap=None):
    seen, out = set(), []
    for l in lines:
        l = l.strip()
        if len(l) < 15 or len(l.split()) < 3 or l in seen:
            continue
        seen.add(l)
        out.append(l)
    return out[:cap] if cap else out


def load_real(mo_dir, site_dir):
    tr = clean(sum((mo_lines(os.path.join(mo_dir, f)) for f in MO_TRAIN), []), 3000) + \
         clean(sum((site_lines(os.path.join(site_dir, f)) for f in SITE_TRAIN), []))
    te = clean(sum((mo_lines(os.path.join(mo_dir, f)) for f in MO_TEST), []), 3000) + \
         clean(sum((site_lines(os.path.join(site_dir, f)) for f in SITE_TEST), []))
    te = [l for l in te if l not in set(tr)]
    return tr, te


def train(lines, real=None):
    from sklearn.linear_model import LogisticRegression
    vec = vectorizer()
    texts = [l[0] for l in lines] + (real or [])
    y = np.array([l[1] for l in lines] + [False] * len(real or []))
    m = LogisticRegression(C=10.0, class_weight="balanced", max_iter=3000).fit(vec.transform(texts), y)
    return vec, m


def choose_threshold(scores, y, rule_flags, hybrid):
    """Kleinste Leckrate bei Fehlalarmen <= MAX_FA_INNER (auf den inneren Halte-Arten)."""
    scores, y, rule = np.asarray(scores), np.asarray(y, bool), np.asarray(rule_flags, bool)
    cands = np.unique(np.concatenate([np.quantile(scores, np.linspace(0, 1, 401)), [0.0]]))
    best = None
    for t in cands:
        pred = (scores > t) | rule if hybrid else scores > t
        fa = (pred & ~y).sum() / max(1, (~y).sum())
        leak = (~pred & y).sum() / max(1, y.sum())
        if fa <= MAX_FA_INNER and (best is None or leak < best[1] or (leak == best[1] and fa < best[2])):
            best = (float(t), float(leak), float(fa))
    if best is None:                               # keine Schwelle hält die Grenze: alles durchlassen
        best = (float(scores.max()) + 1.0, None, None)
    return best[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pruefstand", default="../pii-pruefstand")
    ap.add_argument("--site", default="..")
    ap.add_argument("--mo-dir", default="/usr/share/locale/de/LC_MESSAGES")
    ap.add_argument("--out", default="ergebnisse/m6_hybrid.json")
    ap.add_argument("--n-enc", type=int, default=200)
    a = ap.parse_args()

    sys.path.insert(0, os.path.abspath(a.pruefstand))
    from pruefstand.generator import generate
    from pruefstand.detectors import detect_referenz

    docs = generate(N_DOCS, seed=SEED_DOCS)
    per = [segments(d, detect_referenz) for d in docs]
    kinds = sorted({d.kind for d in docs})
    real_tr, real_te = load_real(a.mo_dir, a.site)
    real_te_rule = [bool(detect_referenz(l)) for l in real_te]
    res = {"daten": {"dokumente": N_DOCS, "seed": SEED_DOCS, "echte_saetze_training": len(real_tr),
                     "echte_saetze_test": len(real_te), "quellen_training": MO_TRAIN + SITE_TRAIN,
                     "quellen_test": MO_TEST + SITE_TEST, "max_fehlalarme_innen": MAX_FA_INNER},
           "beispiele_echt_test": real_te[:5] + real_te[-5:]}
    print(res["daten"])

    methods = ["regeln", "modell_nur_synthetisch", "modell_mit_echt", "modell_mit_echt_eingestellt", "hybrid"]
    pooled = {m: ([], [], []) for m in methods}
    real_fa = {m: [] for m in methods}
    thresholds = {"modell_mit_echt_eingestellt": {}, "hybrid": {}}
    t0 = time.time()
    for k in kinds:
        tr = [l for p in per for l in p if l[4] != k]
        te = [l for p in per for l in p if l[4] == k]
        inner = sorted({l[4] for l in tr})

        # innere Kreuzvalidierung zur Wahl der Schwellen (sieht die Test-Art nie)
        sc, yy, rr = [], [], []
        for j in inner:
            v, m = train([l for l in tr if l[4] != j], real_tr)
            hold = [l for l in tr if l[4] == j]
            sc += list(m.decision_function(v.transform([l[0] for l in hold])))
            yy += [l[1] for l in hold]
            rr += [l[3] for l in hold]
        t_model = choose_threshold(sc, yy, rr, hybrid=False)
        t_hyb = choose_threshold(sc, yy, rr, hybrid=True)
        thresholds["modell_mit_echt_eingestellt"][k] = t_model
        thresholds["hybrid"][k] = t_hyb

        v0, m0 = train(tr)
        v1, m1 = train(tr, real_tr)
        s0 = m0.decision_function(v0.transform([l[0] for l in te]))
        s1 = m1.decision_function(v1.transform([l[0] for l in te]))
        r_te = np.array([l[3] for l in te])
        preds = {"regeln": r_te, "modell_nur_synthetisch": s0 > 0, "modell_mit_echt": s1 > 0,
                 "modell_mit_echt_eingestellt": s1 > t_model, "hybrid": (s1 > t_hyb) | r_te}
        e0 = m0.decision_function(v0.transform(real_te))
        e1 = m1.decision_function(v1.transform(real_te))
        rre = np.array(real_te_rule)
        real_preds = {"regeln": rre, "modell_nur_synthetisch": e0 > 0, "modell_mit_echt": e1 > 0,
                      "modell_mit_echt_eingestellt": e1 > t_model, "hybrid": (e1 > t_hyb) | rre}
        for mth in methods:
            pooled[mth][0].extend(preds[mth]); pooled[mth][1].extend(l[1] for l in te); pooled[mth][2].extend(l[2] for l in te)
            real_fa[mth].append(float(np.mean(real_preds[mth])))
        print(f"{k:13s} t_mod={t_model:+.2f} t_hyb={t_hyb:+.2f} | " + " | ".join(
            f"{mth[:12]} L{(~np.asarray(preds[mth]) & np.array([l[1] for l in te])).sum() / max(1, sum(l[1] for l in te)):.3f}"
            for mth in methods) + f"  ({time.time() - t0:.0f}s)")

    res["B_unbekannte_formate"] = {m: rates(*pooled[m]) for m in methods}
    for m in methods:
        res["B_unbekannte_formate"][m]["fehlalarme_echte_saetze_mittel"] = float(np.mean(real_fa[m]))
    res["schwellen"] = thresholds

    # Beispiele: echte Testsätze, die der Hybrid fälschlich sperrt (letztes Fold-Modell)
    flagged = [l for l, f in zip(real_te, (e1 > t_hyb) | rre) if f]
    res["beispiele_fehlalarm_echt_hybrid"] = flagged[:12]
    leaks = Counter()
    for l, p in zip(te, (s1 > t_hyb) | r_te):
        if l[1] and not p:
            leaks[l[0][:60]] += 1
    res["beispiele_leck_hybrid_letzte_art"] = [x for x, _ in leaks.most_common(8)]

    # ---- verschlüsselt: Hybrid auf der letzten Test-Art (Regeln beim Client, Modell verschlüsselt)
    from hlab.engine import CKKSSession
    from hlab.linear import EncryptedLinearModel
    n = min(a.n_enc, len(te))
    enc = EncryptedLinearModel.from_sklearn(m1, session=CKKSSession(depth=2, slots=4096))
    X = v1.transform([l[0] for l in te[:n]]).toarray()
    agree, times = 0, []
    for i in range(n):
        scores, t = enc.predict_row(X[i])
        agree += int(((scores[0] > t_hyb) or r_te[i]) == ((s1[i] > t_hyb) or r_te[i]))
        times.append(t.total())
    res["verschluesselt_hybrid"] = {"art": kinds[-1], "zeilen": n, "gleiche_entscheidung": agree,
                                    "ms_pro_zeile_median": float(st.median(times)) * 1e3}

    print(json.dumps({m: {k: v for k, v in r.items() if k != "verpasste_angaben"}
                      for m, r in res["B_unbekannte_formate"].items()}, indent=1, ensure_ascii=False))
    print("verschlüsselt:", res["verschluesselt_hybrid"])
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    print("geschrieben:", a.out)


if __name__ == "__main__":
    main()
