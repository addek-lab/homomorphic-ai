#!/usr/bin/env python3
"""Erzeugt Beispieldateien für Experiment 5: ein trainiertes Modell und ein paar Datenzeilen.

Danach:  python run.py 5 --model beispiel_modell.joblib --csv beispiel_daten.csv
"""
import joblib
import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

data = load_breast_cancer()
Xtr, Xte, ytr, _ = train_test_split(data.data, data.target, test_size=0.2, random_state=1, stratify=data.target)
pipe = make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000)).fit(Xtr, ytr)

joblib.dump(pipe, "beispiel_modell.joblib")
np.savetxt("beispiel_daten.csv", Xte[:10], delimiter=",", header=",".join(data.feature_names), comments="")
print("Geschrieben: beispiel_modell.joblib, beispiel_daten.csv")
