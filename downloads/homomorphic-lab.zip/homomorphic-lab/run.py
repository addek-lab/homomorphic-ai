#!/usr/bin/env python3
"""Startpunkt des Homomorphic Lab.

  python run.py            Menü
  python run.py 3          Experiment 3 starten
  python run.py 3 --n 50 --sigmoid
  python run.py 5 --model beispiel_modell.joblib --csv beispiel_daten.csv
"""
import argparse
import sys

EXPERIMENTS = {
    "1": "Hallo, verschlüsselte Welt (Addition, Multiplikation, Rotation)",
    "2": "Rauschen und Rechentiefe",
    "3": "Verschlüsselte Krebs-Diagnose mit einem normalen KI-Modell",
    "4": "Parameter und ihre Kosten",
    "5": "Dein eigenes scikit-learn-Modell (joblib + CSV)",
}


def main(argv=None):
    ap = argparse.ArgumentParser(description="Homomorphic Lab", formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument("experiment", nargs="?", choices=EXPERIMENTS, help="Nummer des Experiments (1-5)")
    ap.add_argument("--n", type=int, default=None, help="Anzahl Beispiele (Exp. 3 und 5)")
    ap.add_argument("--sigmoid", action="store_true", help="Sigmoid-Funktion unter Verschlüsselung (binäre Modelle)")
    ap.add_argument("--model", help="Pfad zu einer joblib-Datei mit scikit-learn-Modell (Exp. 5)")
    ap.add_argument("--csv", help="Pfad zu einer CSV-Datei mit Merkmalen, eine Zeile pro Beispiel (Exp. 5)")
    args = ap.parse_args(argv)

    exp = args.experiment
    if exp is None:
        print("\nHomomorphic Lab: Experimente mit verschlüsselter KI\n")
        for k, v in EXPERIMENTS.items():
            print(f"  {k}) {v}")
        try:
            exp = input("\nWelches Experiment? [1-5]: ").strip()
        except EOFError:
            sys.exit("\nKeine Eingabe möglich (kein interaktives Terminal). Starte mit Docker 'docker run --rm -it ...' "
                     "oder gib die Nummer direkt an, z. B.: python run.py 3")
        if exp not in EXPERIMENTS:
            sys.exit("Ungültige Eingabe.")

    from hlab import experiments as E   # erst hier importieren, damit --help ohne OpenFHE funktioniert

    if exp == "1":
        E.exp_hello()
    elif exp == "2":
        E.exp_depth()
    elif exp == "3":
        E.exp_logreg(n=args.n or 20, use_sigmoid=args.sigmoid)
    elif exp == "4":
        E.exp_params()
    elif exp == "5":
        if not (args.model and args.csv):
            sys.exit("Experiment 5 braucht --model und --csv. Beispieldateien erzeugt: python make_example.py")
        E.exp_own(args.model, args.csv, n=args.n or 10, use_sigmoid=args.sigmoid)


if __name__ == "__main__":
    main()
