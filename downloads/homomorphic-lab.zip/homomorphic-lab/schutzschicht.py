"""Schutzschicht: Personendaten lokal maskieren, bevor ein Text an eine KI geht, und die Antwort zurückübersetzen.

Prototyp zur Forschungslinie M5 bis M8. Alles Erkennen passiert auf diesem Rechner:
  1. Regeln des Datenschutz-Prüfstands (IBAN, Kartennummer, Steuer-ID, KVNR, Telefon, ...)
  2. Eigennamenerkennung für Personen (Transformer, optional: braucht torch + transformers)
  3. Wörterbuch für Arzneimittel und Krankheiten aus Wikidata (daten/, siehe fetch_wikidata.py)

Die Zuordnung Platzhalter -> Originalwert bleibt im Speicher dieses Programms. An die KI geht nur der
maskierte Text. Ohne KI-Zugang zeigt das Programm nur, was gesendet würde.

Beispiele:
  python schutzschicht.py --text "Bitte überweise 200 € an Dmitri Wagner, IBAN DE89 3704 0044 0532 0130 00."
  python schutzschicht.py --datei brief.txt --frage "Fasse den Brief in zwei Sätzen zusammen."

Optional mit einer KI über eine OpenAI-kompatible Schnittstelle (z. B. ein lokales Modell):
  SCHUTZ_KI_URL=http://localhost:11434/v1/chat/completions SCHUTZ_KI_MODELL=llama3.1 \
  python schutzschicht.py --datei brief.txt --frage "Fasse zusammen."
  (Schlüssel, falls nötig, in SCHUTZ_KI_SCHLUESSEL)

PROTOTYP, KEIN PRODUKT: Die Erkennung übersieht Angaben (im Prüfstand rund 4 % der Angaben, auf echten
Texten unbekannt). Prüfe den maskierten Text, bevor du ihn irgendwohin schickst.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
NER_MODEL = "Davlan/bert-base-multilingual-cased-ner-hrl"


def _find_pruefstand(path):
    for p in (path, os.path.join(HERE, "..", "pii-pruefstand"), os.path.join(HERE, "pii-pruefstand")):
        if p and os.path.isdir(os.path.join(p, "pruefstand")):
            return os.path.abspath(p)
    sys.exit("Ordner 'pii-pruefstand' nicht gefunden. Mit --pruefstand angeben "
             "(https://github.com/addek-lab/pii-pruefstand).")


class Schutzschicht:
    def __init__(self, pruefstand=None, ner=True):
        sys.path.insert(0, _find_pruefstand(pruefstand))
        from pruefstand.core import Span
        from pruefstand.detectors import detect_referenz, resolve
        from pruefstand.masking import mask, restore
        sys.path.insert(0, HERE)
        from experiment_kette import load_lexicon, build_matcher

        self._Span, self._rules, self._resolve, self._mask, self._restore = Span, detect_referenz, resolve, mask, restore
        self.lex = {}
        for lab, fn in (("MEDIKAMENT", "wikidata_arzneimittel_de.txt"), ("DIAGNOSE", "wikidata_krankheiten_de.txt")):
            path = os.path.join(HERE, "daten", fn)
            if os.path.exists(path):
                terms = [t for t in load_lexicon(path) if t.lower() not in {"icd-10", "simulation"}]
                self.lex[lab] = build_matcher(terms)
        self.ner = None
        if ner:
            try:
                from transformers import pipeline
                self.ner = pipeline("token-classification", model=NER_MODEL, aggregation_strategy="simple", device=-1)
            except Exception as e:                         # noqa: BLE001 - Prototyp: ohne NER weiterlaufen
                print(f"Hinweis: Eigennamenerkennung nicht verfügbar ({type(e).__name__}). "
                      "Namen ohne Anrede werden dann eher übersehen.", file=sys.stderr)

    def erkennen(self, text):
        spans = list(self._rules(text))
        if self.ner:
            spans += [self._Span(int(e["start"]), int(e["end"]), "PERSON")
                      for e in self.ner(text) if e["entity_group"] == "PER"]
        for lab, rx in self.lex.items():
            spans += [self._Span(m.start(), m.end(), lab) for m in rx.finditer(text)]
        return self._resolve(spans)

    def maskieren(self, text):
        return self._mask(text, self.erkennen(text))

    def zurueck(self, text, zuordnung):
        return self._restore(text, zuordnung)


def frage_ki(prompt):
    url = os.environ.get("SCHUTZ_KI_URL")
    if not url:
        return None
    body = {"model": os.environ.get("SCHUTZ_KI_MODELL", "default"),
            "messages": [{"role": "system", "content": "Antworte auf Deutsch. Platzhalter wie [PERSON_1] "
                                                       "unverändert übernehmen."},
                         {"role": "user", "content": prompt}]}
    headers = {"Content-Type": "application/json"}
    if os.environ.get("SCHUTZ_KI_SCHLUESSEL"):
        headers["Authorization"] = "Bearer " + os.environ["SCHUTZ_KI_SCHLUESSEL"]
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers=headers)
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.load(r)["choices"][0]["message"]["content"]


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--text")
    src.add_argument("--datei")
    ap.add_argument("--frage", default="Fasse den folgenden Text kurz zusammen.")
    ap.add_argument("--pruefstand")
    ap.add_argument("--ohne-ner", action="store_true", help="ohne Eigennamenerkennung (schneller, schwächer)")
    ap.add_argument("--zeige-zuordnung", action="store_true", help="Zuordnung lokal anzeigen")
    a = ap.parse_args()

    text = a.text if a.text is not None else open(a.datei, encoding="utf-8").read()
    s = Schutzschicht(a.pruefstand, ner=not a.ohne_ner)
    masked, mapping = s.maskieren(text)

    print("=== Das würde an die KI gehen " + "=" * 40)
    print(f"{a.frage}\n\n{masked}")
    print(f"\n({len(mapping)} Angaben durch Platzhalter ersetzt; die Zuordnung bleibt auf diesem Rechner.)")
    if a.zeige_zuordnung:
        print("\n=== Zuordnung (nur lokal) " + "=" * 44)
        for ph, val in mapping.items():
            print(f"  {ph:16s} {val}")

    antwort = frage_ki(f"{a.frage}\n\n{masked}")
    if antwort is None:
        print("\nKeine KI konfiguriert (SCHUTZ_KI_URL). Es wurde nichts gesendet.")
        return
    print("\n=== Antwort der KI (mit Platzhaltern) " + "=" * 32)
    print(antwort)
    print("\n=== Zurückübersetzt (nur lokal) " + "=" * 38)
    print(s.zurueck(antwort, mapping))


if __name__ == "__main__":
    main()
