"""M8: Die ganze lokale Schutzkette, gemessen mit der Kennzahl des Datenschutz-Prüfstands.

Kette (alles lokal, im Klartext, auf dem Gerät des Nutzers):
  1. Regeln des Prüfstands (Prüfsummen, Kontext)
  2. Eigennamenerkennung (Transformer) für Personen        -> schließt die Namens-Lücke (M7)
  3. Wörterbuch aus Wikidata für Arzneimittel und Krankheiten -> soll die medizinische Lücke schließen

Das Wörterbuch (fetch_wikidata.py) ist unabhängig vom Prüfstand entstanden. Gefiltert werden nur
Einträge, die in den HARMLOSEN TRAININGSSÄTZEN aus M6 vorkommen (z. B. Alltagswörter), nie anhand
der Testdaten.

Gemessen wird:
  A  die offizielle Prüfstand-Kennzahl ("geschützt": >= 80 % einer Angabe maskiert) auf denselben
     300 Dokumenten (Seed 1) wie im veröffentlichten Benchmark, plus Fehlalarme und Wiedererkennbarkeit
  B  Zeilen-Lecks und Fehlalarme wie in M5 bis M7 (1.200 Dokumente, Seed 11) und auf echten Sätzen
  C  Rundreise: maskieren, (simulierte) KI-Antwort, zurückübersetzen -> kommen alle Werte korrekt zurück?

Aufruf (braucht torch + transformers):
  python experiment_kette.py --pruefstand ../pii-pruefstand --site .. --mo-dir /usr/share/locale/de/LC_MESSAGES
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time

import numpy as np

from experiment_routing import N_DOCS, SEED_DOCS, segments, rates
from experiment_hybrid import load_real, MO_TRAIN, SITE_TRAIN
from experiment_ner import HF_DEFAULT

MIN_LEN = 4


def load_lexicon(path):
    with open(path, encoding="utf-8") as f:
        return [l.strip() for l in f if l.strip() and not l.startswith("#")]


_TOKEN = re.compile(r"[\wÄÖÜäöüß]+(?:[-'][\wÄÖÜäöüß]+)*")


class _Match:
    def __init__(self, s, e, text):
        self._s, self._e, self._t = s, e, text

    def start(self): return self._s
    def end(self): return self._e
    def group(self, _=0): return self._t


class build_matcher:
    """Findet Begriffe als ganze Wortfolgen (ohne Groß/klein), längste Folge zuerst.
    Schneller als ein regulärer Ausdruck mit tausenden Alternativen."""

    def __init__(self, terms):
        self.terms, self.maxw = set(), 1
        for t in terms:
            if len(t) < MIN_LEN:
                continue
            toks = _TOKEN.findall(t.lower())
            if toks and " ".join(toks) == " ".join(t.lower().split()):   # nur "normale" Wortfolgen
                self.terms.add(tuple(toks))
                self.maxw = max(self.maxw, len(toks))

    def finditer(self, text):
        toks = [(m.group(0).lower(), m.start(), m.end()) for m in _TOKEN.finditer(text)]
        i = 0
        while i < len(toks):
            for n in range(min(self.maxw, len(toks) - i), 0, -1):
                if tuple(t[0] for t in toks[i:i + n]) in self.terms:
                    s, e = toks[i][1], toks[i + n - 1][2]
                    yield _Match(s, e, text[s:e])
                    i += n
                    break
            else:
                i += 1

    def __bool__(self):
        return bool(self.terms)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pruefstand", default="../pii-pruefstand")
    ap.add_argument("--site", default="..")
    ap.add_argument("--mo-dir", default="/usr/share/locale/de/LC_MESSAGES")
    ap.add_argument("--hf-model", default=HF_DEFAULT)
    ap.add_argument("--out", default="ergebnisse/m8_kette.json")
    a = ap.parse_args()

    sys.path.insert(0, os.path.abspath(a.pruefstand))
    from pruefstand import data
    from pruefstand.core import Span
    from pruefstand.detectors import detect_referenz, resolve
    from pruefstand.evaluate import evaluate
    from pruefstand.generator import generate
    from pruefstand.masking import mask, restore

    # ---- Wörterbuch ----------------------------------------------------------------------
    drugs = load_lexicon("daten/wikidata_arzneimittel_de.txt")
    diseases = load_lexicon("daten/wikidata_krankheiten_de.txt")
    real_tr, real_te = load_real(a.mo_dir, a.site)
    raw = {"MEDIKAMENT": build_matcher(drugs), "DIAGNOSE": build_matcher(diseases)}
    # Stoppliste nur aus harmlosen TRAININGSSÄTZEN
    stop = {lab: set() for lab in raw}
    for s in real_tr:
        for lab, rx in raw.items():
            for m in rx.finditer(s):
                stop[lab].add(m.group(0).lower())
    lex = {"MEDIKAMENT": build_matcher([t for t in drugs if t.lower() not in stop["MEDIKAMENT"]]),
           "DIAGNOSE": build_matcher([t for t in diseases if t.lower() not in stop["DIAGNOSE"]])}
    lex_info = {"arzneimittel": len(drugs), "krankheiten": len(diseases),
                "stoppliste_arzneimittel": sorted(stop["MEDIKAMENT"]), "stoppliste_krankheiten": sorted(stop["DIAGNOSE"]),
                "quellen_stoppliste": MO_TRAIN + SITE_TRAIN}
    # Abdeckung der im Generator verwendeten Begriffe (nur zur Einordnung, nicht zum Anpassen)
    lower_d, lower_k = {t.lower() for t in drugs}, {t.lower() for t in diseases}
    lex_info["generator_medikamente_im_woerterbuch"] = [m for m in data.MEDICATIONS if m.lower() in lower_d]
    lex_info["generator_medikamente_fehlen"] = [m for m in data.MEDICATIONS if m.lower() not in lower_d]
    lex_info["generator_diagnosen_im_woerterbuch"] = [d for _, d in data.DIAGNOSES if d.lower() in lower_k]
    lex_info["generator_diagnosen_fehlen"] = [d for _, d in data.DIAGNOSES if d.lower() not in lower_k]
    print(json.dumps({k: v for k, v in lex_info.items() if not k.startswith("stoppliste")}, ensure_ascii=False, indent=1))
    print("Stoppliste:", len(stop["MEDIKAMENT"]), "Arzneimittel,", len(stop["DIAGNOSE"]), "Krankheiten")

    def lex_spans(text):
        return [Span(m.start(), m.end(), lab) for lab, rx in lex.items() if rx for m in rx.finditer(text)]

    # NACHTRÄGLICHE BEREINIGUNG (offen ausgewiesen): Beim Auswerten zeigte sich, dass alle zusätzlichen
    # Fehlalarme des Wörterbuchs auf einen Eintrag zurückgehen: "ICD-10" ist in Wikidata als
    # Bezeichnung einer Krankheit hinterlegt. Diese Variante entfernt nur diesen einen Eintrag.
    POST_HOC = {"icd-10"}
    lex_clean = {"MEDIKAMENT": lex["MEDIKAMENT"],
                 "DIAGNOSE": build_matcher([t for t in diseases if t.lower() not in stop["DIAGNOSE"]
                                            and t.lower() not in POST_HOC])}
    lex_info["nachtraeglich_entfernt"] = sorted(POST_HOC)

    def lex_spans_clean(text):
        return [Span(m.start(), m.end(), lab) for lab, rx in lex_clean.items() if rx for m in rx.finditer(text)]

    # ---- Eigennamenerkennung -------------------------------------------------------------
    from transformers import pipeline
    import torch
    torch.set_num_threads(os.cpu_count() or 4)
    ner = pipeline("token-classification", model=a.hf_model, aggregation_strategy="simple", device=-1)

    def ner_spans(texts):
        out = []
        for i in range(0, len(texts), 32):
            for ents in ner(texts[i:i + 32]):
                out.append([Span(int(e["start"]), int(e["end"]), "PERSON") for e in ents if e["entity_group"] == "PER"])
        return out

    # ---- A: offizielle Prüfstand-Kennzahl --------------------------------------------------
    docs = generate(300, seed=1)
    t0 = time.perf_counter()
    ner_doc = ner_spans([d.text for d in docs])
    t_ner = (time.perf_counter() - t0) / len(docs)
    cache = {d.text: n for d, n in zip(docs, ner_doc)}
    variants = {
        "referenz": lambda t: detect_referenz(t),
        "referenz_ner": lambda t: resolve(detect_referenz(t) + cache[t]),
        "referenz_woerterbuch": lambda t: resolve(detect_referenz(t) + lex_spans(t)),
        "kette": lambda t: resolve(detect_referenz(t) + cache[t] + lex_spans(t)),
        "kette_nachtraeglich_bereinigt": lambda t: resolve(detect_referenz(t) + cache[t] + lex_spans_clean(t)),
    }
    A = {}
    for name, fn in variants.items():
        r = evaluate(docs, fn)
        A[name] = {k: r[k] for k in ("protected_pct", "leaked", "critical_protected_pct", "critical_leaked",
                                     "false_alarms_per_100_docs", "reidentifiable_pct")}
        A[name]["domains"] = {k: v["protected_pct"] for k, v in r["domains"].items()}
        A[name]["per_label"] = {k: v["protected_pct"] for k, v in r["per_label"].items()}
        A[name]["misses"] = r["misses"]
        print("A", name, {k: A[name][k] for k in ("protected_pct", "critical_protected_pct",
                                                  "false_alarms_per_100_docs", "reidentifiable_pct")})
    A["ner_ms_pro_dokument"] = t_ner * 1e3

    # ---- B: Zeilen wie M5 bis M7 ----------------------------------------------------------
    docs_b = generate(N_DOCS, seed=SEED_DOCS)
    lines = [l for d in docs_b for l in segments(d, detect_referenz)]
    texts = [l[0] for l in lines]
    per = np.array([bool(s) for s in ner_spans(texts)])
    lx = np.array([bool(lex_spans(t)) for t in texts])
    rule = np.array([l[3] for l in lines])
    real = real_tr + real_te
    real_test = real_te                                  # Stoppliste stammt aus real_tr -> fair nur auf real_te
    per_r = np.array([bool(s) for s in ner_spans(real_test)])
    lx_r = np.array([bool(lex_spans(t)) for t in real_test])
    rule_r = np.array([bool(detect_referenz(t)) for t in real_test])
    y, g = [l[1] for l in lines], [l[2] for l in lines]
    B = {}
    for name, p, pr in (("regeln", rule, rule_r), ("regeln_ner", rule | per, rule_r | per_r),
                        ("kette", rule | per | lx, rule_r | per_r | lx_r)):
        r = rates(p, y, g)
        r["fehlalarme_echte_testsaetze"] = float(np.mean(pr))
        B[name] = r
        print("B", name, f"Leck {r['leckrate']*100:.1f} FA {r['fehlalarmrate']*100:.1f} "
                         f"FAecht {r['fehlalarme_echte_testsaetze']*100:.1f}", r["verpasste_angaben"])
    B["echte_testsaetze"] = len(real_test)
    B["beispiele_fehlalarm_echt_woerterbuch"] = [t for t, f in zip(real_test, lx_r) if f][:10]
    B["beispiele_woerterbuch_treffer_dokumente"] = sorted({m.group(0) for t in texts[:3000] for rx in lex.values()
                                                           if rx for m in rx.finditer(t)})[:40]

    # ---- C: Rundreise ------------------------------------------------------------------------
    ok = total_ph = 0
    example = None
    for d in docs[:100]:
        spans = variants["kette"](d.text)
        masked, mapping = mask(d.text, spans)
        # simulierte KI: antwortet mit einer Zusammenfassung, die die Platzhalter in anderer Reihenfolge nennt
        answer = "Zusammenfassung: " + " / ".join(reversed(list(mapping))) + "."
        back = restore(answer, mapping)
        total_ph += len(mapping)
        ok += sum(1 for ph, val in mapping.items() if val in back and ph not in back)
        if example is None and len(mapping) >= 5:
            example = {"original": d.text, "an_die_ki": masked, "ki_antwort": answer, "zurueckuebersetzt": back}
    C = {"dokumente": 100, "platzhalter": total_ph, "korrekt_zurueck": ok, "beispiel": example}
    print("C", {k: v for k, v in C.items() if k != "beispiel"})

    res = {"woerterbuch": lex_info, "A_pruefstand_kennzahl": A, "B_zeilen": B, "C_rundreise": C,
           "ner_modell": a.hf_model}
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    print("geschrieben:", a.out)


if __name__ == "__main__":
    main()
