# Homomorphic Lab

Kleine Experimente mit **verschlüsselter KI-Inferenz**. Das Lab nutzt die Open-Source-Bibliothek
[OpenFHE](https://openfhe.org) (Verfahren CKKS) und lässt ganz normale scikit-learn-Modelle auf
verschlüsselten Daten rechnen. Der „Server“ sieht dabei weder die Eingabe noch das Ergebnis.

Das Lab ist zum Lernen und Ausprobieren gedacht, **nicht für den Produktivbetrieb** (siehe „Grenzen“).

**Teststand:** Alle fünf Experimente liefen gegen OpenFHE 1.6.1 unter Linux (ARM64, aus dem Quellcode
gebaut). Das Docker-Image (x86_64) und das pip-Paket `openfhe` wurden von mir noch nicht selbst
ausgeführt. Rückmeldungen sind willkommen.

## Was du damit machen kannst

| # | Experiment | Was du lernst |
|---|-----------|---------------|
| 1 | Hallo, verschlüsselte Welt | Addieren, Multiplizieren und Verschieben auf Chiffretext |
| 2 | Rauschen und Rechentiefe | Warum nur begrenzt viele Multiplikationen hintereinander gehen |
| 3 | Verschlüsselte Krebs-Diagnose | Ein normales KI-Modell sagt auf verschlüsselten Messwerten voraus |
| 4 | Parameter und ihre Kosten | Wie Tiefe und Genauigkeit Größe und Geschwindigkeit verändern |
| 5 | Dein eigenes Modell | Eigenes scikit-learn-Modell (joblib) + CSV-Daten verschlüsselt auswerten |

## Voraussetzungen

Das pip-Paket `openfhe` gibt es **nur für Linux auf x86_64 mit Python 3.12**. Auf Windows und macOS
läuft das Lab deshalb in Docker (empfohlen) oder in WSL2.

## Schnellstart mit Docker

```bash
docker build -t homomorphic-lab .
docker run --rm -it homomorphic-lab                 # Menü
docker run --rm -it homomorphic-lab python run.py 3 # Experiment 3 direkt
```

Auf ARM-Rechnern (z. B. Apple Silicon) startet Docker den Container per Emulation. Das ist langsamer,
funktioniert aber.

## Schnellstart ohne Docker (Linux x86_64 oder WSL2 mit x86_64-Ubuntu, Python 3.12)

```bash
python3.12 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python run.py
```

## Beispiele

```bash
python run.py 1                       # Hallo-Welt
python run.py 3 --n 50                # 50 Patienten verschlüsselt auswerten
python run.py 3 --sigmoid             # auch die Sigmoid-Funktion unter Verschlüsselung (Polynom-Näherung)
python run.py 4                       # Parametervergleich
```

### Eigenes Modell (Experiment 5)

```bash
python make_example.py                # erzeugt beispiel_modell.joblib und beispiel_daten.csv
python run.py 5 --model beispiel_modell.joblib --csv beispiel_daten.csv
```

Unterstützt werden Modelle mit `coef_` und `intercept_` (LogisticRegression, LinearRegression, Ridge,
LinearSVC, …), auch in einer `Pipeline`. Die Vorverarbeitung (z. B. StandardScaler) läuft dabei beim
Client im Klartext.

> **Vorsicht:** joblib-/pickle-Dateien können beim Laden Code ausführen. Lade nur Dateien, denen du vertraust.

## So funktioniert es

```
Client                       Server
  │  x verschlüsseln            │
  │ ───── Chiffretext ────────▶ │  rechnet <w, x> + b auf dem Chiffretext
  │ ◀──── Chiffretext ───────── │  (Gewichte w liegen im Klartext vor)
  │  Ergebnis entschlüsseln
```

- Merkmale werden in **einen** Chiffretext gepackt (SIMD), ein Skalarprodukt ist eine Multiplikation
  plus eine Summe über die Slots.
- Die Sigmoid-Funktion lässt sich nur als Polynom (hier Grad 15) auswerten, und das gilt nur in einem
  festen Wertebereich. Im Lab wird der Bereich aus den Daten bestimmt; in der Praxis müsste man ihn vorab
  festlegen. Außerhalb des Bereichs liefert das Polynom falsche Werte, und je größer der Bereich, desto
  gröber die Näherung (im Beispiel Abweichungen bis etwa 0,1 bei den Wahrscheinlichkeiten). Ohne
  `--sigmoid` entschlüsselt der Client den Rohwert und wendet die Funktion selbst an, das ist genauer.
- Neuronale Netze mit ReLU sind mit CKKS nicht direkt möglich, dafür braucht es andere Verfahren oder
  Polynom-Aktivierungen. Das Lab beschränkt sich bewusst auf lineare Modelle.

## Grenzen und Sicherheit

- **Lehrcode, kein Produkt.** Schlüsselverwaltung, Rotation der Schlüssel, Schutz vor Seitenkanälen und
  Netzwerkübertragung sind nicht umgesetzt.
- Es wird nur die **Inferenz** gezeigt, kein Training auf verschlüsselten Daten.
- CKKS ist ein **Näherungsverfahren**: Ergebnisse weichen minimal vom Klartext ab. Die Experimente zeigen
  den Abstand.
- Bei Modellen mit sehr vielen Merkmalen steigen Chiffretext-Größe und Rechenzeit stark.
- Verschlüsselung schützt Ein- und Ausgabe, **nicht** vor Angriffen auf das Modell selbst
  (z. B. Model Extraction).

## Lizenz

MIT (siehe `LICENSE`). OpenFHE steht unter der BSD-2-Clause-Lizenz.
