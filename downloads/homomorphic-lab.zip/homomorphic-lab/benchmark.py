"""Messreihe des Homomorphic Lab: reproduzierbare eigene Messungen mit OpenFHE (CKKS).

Aufruf:  python benchmark.py [--out ergebnisse/messung.json] [--pruefstand ../pii-pruefstand]

Fragen:
  M1  Stimmt die verschlüsselte Vorhersage mit der Klartext-Vorhersage überein?
      (logistische Regression, Brustkrebs-Datensatz, kompletter Testsatz)
  M2  Was passiert, wenn auch die Sigmoid-Funktion verschlüsselt läuft und ihr Wertebereich
      vorab festgelegt werden muss, ohne die Testdaten zu kennen?
  M3  Wie skaliert die verschlüsselte Inferenz mit der Zahl der Merkmale? Als Beispiel dient ein
      linearer Textklassifikator auf synthetischen deutschen Finanz- und Gesundheitsdokumenten
      (aus dem Datenschutz-Prüfstand).
  M4  Was kosten mehr Rechentiefe und Genauigkeit (Ringdimension, Schlüssel, Chiffretext)?

Alle Zeiten sind Wandzeit auf der ausführenden Maschine, ein Thread pro Vorgang wie in OpenFHE
voreingestellt. Absolute Zahlen hängen stark von der Hardware ab; Verhältnisse sind aussagekräftiger.
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import statistics as st
import sys
import time

import numpy as np

from hlab.engine import CKKSSession, next_pow2
from hlab.linear import EncryptedLinearModel, sigmoid


def med(xs):
    return float(st.median(xs))


def p95(xs):
    return float(np.percentile(xs, 95))


def plain_time_per_row(model, X, reps=200):
    """Klartext-Vorhersage Zeile für Zeile (fairer Vergleich zur verschlüsselten Einzelanfrage)."""
    ts = []
    for i in range(min(reps, len(X))):
        t0 = time.perf_counter()
        model.decision_function(X[i:i + 1])
        ts.append(time.perf_counter() - t0)
    return med(ts)


def run_encrypted(enc, model, X, use_sigmoid=False):
    plain_cls = model.predict(X)
    plain_raw = model.decision_function(X)
    agree, errs, t_enc, t_eval, t_dec = 0, [], [], [], []
    size = 0
    for i in range(len(X)):
        cls, scores, t = enc.predict_class(X[i])
        ref = plain_raw[i]
        if np.ndim(ref) == 0:
            ref = sigmoid(ref) if use_sigmoid else ref
            errs.append(float(abs(scores[0] - ref)))
        else:
            errs.append(float(np.max(np.abs(scores - ref))))
        agree += int(model.classes_[cls] == plain_cls[i])
        t_enc.append(t.encrypt); t_eval.append(t.evaluate); t_dec.append(t.decrypt)
        size = t.ct_bytes
    return {
        "n": int(len(X)),
        "agree": int(agree),
        "max_abs_error": max(errs),
        "median_abs_error": med(errs),
        "ms_encrypt_median": med(t_enc) * 1e3,
        "ms_evaluate_median": med(t_eval) * 1e3,
        "ms_evaluate_p95": p95(t_eval) * 1e3,
        "ms_decrypt_median": med(t_dec) * 1e3,
        "ms_total_median": med([a + b + c for a, b, c in zip(t_enc, t_eval, t_dec)]) * 1e3,
        "ciphertext_bytes": int(size),
        "plaintext_bytes": int(X.shape[1] * 8),
        "ring_dim": int(enc.session.ring_dim),
        "slots": int(enc.session.slots),
    }


# --------------------------------------------------------------------------- M1 + M2
def m1_m2():
    from sklearn.datasets import load_breast_cancer
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler

    data = load_breast_cancer()
    Xtr, Xte, ytr, yte = train_test_split(data.data, data.target, test_size=0.2, random_state=0,
                                          stratify=data.target)
    sc = StandardScaler().fit(Xtr)
    Xtr, Xte = sc.transform(Xtr), sc.transform(Xte)
    model = LogisticRegression(max_iter=2000).fit(Xtr, ytr)

    out = {"dataset": "sklearn breast_cancer (569 Faelle, 30 Merkmale), Testsatz 20 %",
           "plain_accuracy": float((model.predict(Xte) == yte).mean())}

    print("M1: Rohwert verschlüsselt, Sigmoid beim Client")
    enc = EncryptedLinearModel.from_sklearn(model)
    r = run_encrypted(enc, model, Xte)
    r["plain_ms_per_row"] = plain_time_per_row(model, Xte) * 1e3
    out["m1"] = r
    print(json.dumps(r, indent=1))

    # M2: Bereich der Polynom-Näherung muss VOR dem Einsatz feststehen.
    z_tr, z_te = np.abs(model.decision_function(Xtr)), np.abs(model.decision_function(Xte))
    variants = {
        "bereich_aus_trainingsdaten": float(np.ceil(1.15 * z_tr.max())),
        "fester_bereich_8": 8.0,
    }
    out["m2"] = {"z_train_max": float(z_tr.max()), "z_test_max": float(z_te.max()), "varianten": {}}
    for name, bound in variants.items():
        print(f"M2: Sigmoid verschlüsselt, Bereich ±{bound:g} ({name})")
        enc = EncryptedLinearModel.from_sklearn(model, encrypted_sigmoid=True, sigmoid_bound=bound)
        r = run_encrypted(enc, model, Xte, use_sigmoid=True)
        r["bound"] = bound
        r["test_outside_range"] = int((z_te > bound).sum())
        # Fehler nur innerhalb des Bereichs (dort, wo die Näherung gelten soll)
        out["m2"]["varianten"][name] = r
        print(json.dumps(r, indent=1))
    return out


# --------------------------------------------------------------------------- M3
def load_docs(pruefstand_dir, n):
    sys.path.insert(0, os.path.abspath(pruefstand_dir))
    from pruefstand.generator import generate
    docs = generate(n, seed=7)
    return [d.text for d in docs], [d.kind for d in docs]


def m3(pruefstand_dir, n_docs=600, n_eval=60):
    from sklearn.feature_extraction.text import HashingVectorizer
    from sklearn.linear_model import LogisticRegression

    texts, kinds = load_docs(pruefstand_dir, n_docs)
    split = int(0.75 * len(texts))
    out = {"dataset": f"{n_docs} synthetische deutsche Dokumente aus dem Prüfstand-Generator (seed 7), "
                      f"{len(set(kinds))} Dokumentarten", "classes": sorted(set(kinds)), "runs": []}
    for n_feat in (256, 1024, 4096):
        vec = HashingVectorizer(n_features=n_feat, alternate_sign=False, norm="l2",
                                ngram_range=(1, 2), lowercase=True)
        Xtr = vec.transform(texts[:split]).toarray()
        Xte = vec.transform(texts[split:]).toarray()[:n_eval]
        ytr, yte = kinds[:split], kinds[split:split + n_eval]
        model = LogisticRegression(max_iter=3000, C=10.0).fit(Xtr, ytr)
        print(f"M3: {n_feat} Merkmale, {len(model.classes_)} Klassen")
        t0 = time.perf_counter()
        session = CKKSSession(depth=2, slots=next_pow2(n_feat))
        setup = time.perf_counter() - t0
        enc = EncryptedLinearModel.from_sklearn(model, session=session)
        r = run_encrypted(enc, model, Xte)
        r.update({"features": n_feat, "classes": int(len(model.classes_)),
                  "plain_accuracy": float((model.predict(Xte) == np.array(yte)).mean()),
                  "plain_ms_per_row": plain_time_per_row(model, Xte) * 1e3,
                  "setup_keygen_ms": setup * 1e3})
        out["runs"].append(r)
        print(json.dumps(r, indent=1))
    return out


# --------------------------------------------------------------------------- M4
def m4(reps=5):
    rows = []
    for depth, bits in [(1, 40), (2, 50), (4, 50), (8, 50), (12, 50), (16, 50)]:
        setups, encs, muls, sizes, ring = [], [], [], [], 0
        for _ in range(reps):
            t0 = time.perf_counter()
            s = CKKSSession(depth=depth, scale_bits=bits, slots=32)
            setups.append(time.perf_counter() - t0)
            t0 = time.perf_counter()
            ct = s.encrypt(list(range(32)))
            encs.append(time.perf_counter() - t0)
            t0 = time.perf_counter()
            s.mul(ct, ct)
            muls.append(time.perf_counter() - t0)
            sizes.append(s.size_bytes(ct))
            ring = s.ring_dim
        r = {"depth": depth, "scale_bits": bits, "ring_dim": int(ring),
             "setup_keygen_ms": med(setups) * 1e3, "encrypt_ms": med(encs) * 1e3,
             "mul_ms": med(muls) * 1e3, "ciphertext_bytes": int(med(sizes))}
        rows.append(r)
        print("M4:", r)
    return {"reps": reps, "rows": rows}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="ergebnisse/messung.json")
    ap.add_argument("--pruefstand", default="../pii-pruefstand")
    a = ap.parse_args()

    import openfhe
    import sklearn
    info = {
        "datum": time.strftime("%Y-%m-%d"),
        "python": platform.python_version(),
        "numpy": np.__version__,
        "sklearn": sklearn.__version__,
        "openfhe_python": getattr(openfhe, "__version__", "1.6.1 (aus Quellcode)"),
        "maschine": platform.machine(),
        "cpu_kerne": os.cpu_count(),
        "system": platform.platform(),
    }
    print(info)
    res = {"info": info}
    res["m1_m2"] = m1_m2()
    res["m3"] = m3(a.pruefstand)
    res["m4"] = m4()
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    print("geschrieben:", a.out)


if __name__ == "__main__":
    main()
