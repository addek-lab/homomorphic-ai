"""M7: Lokale Eigennamenerkennung (NER) gegen die Lecks aus M5/M6.

In M5 und M6 rutschten vor allem Namen ohne Anrede und Medikamente durch die Regeln. Ein gelerntes
lineares Modell (das unter FHE bezahlbar wäre) half nicht. Hier wird geprüft, was eine fertige,
lokal laufende Eigennamenerkennung bringt. Sie braucht kein Training auf den Prüfstand-Daten, also
gibt es keine Vorlagen, die sie auswendig lernen könnte.

Verfahren (--engine):
  spacy  spaCy mit de_core_news_md (klassisches statistisches Modell)
  hf     Transformer-Modell über Hugging Face (Standard: Davlan/bert-base-multilingual-cased-ner-hrl)

Gemessen auf allen 7.412 Zeilen der 1.200 synthetischen Dokumente (wie M5/M6) und auf den echten
harmlosen Sätzen aus M6. Eine Zeile gilt als markiert, wenn eine Person (PER) erkannt wird; Variante
"per_loc" zählt zusätzlich Orte (LOC). Kombiniert wird jeweils mit den Regeln des Prüfstands.

Aufruf:
  python experiment_ner.py --engine spacy --pruefstand ../pii-pruefstand --site .. --mo-dir /usr/share/locale/de/LC_MESSAGES
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from collections import Counter

import numpy as np

from experiment_routing import N_DOCS, SEED_DOCS, segments, rates
from experiment_hybrid import load_real

HF_DEFAULT = "Davlan/bert-base-multilingual-cased-ner-hrl"


def ner_spacy():
    import spacy
    nlp = spacy.load("de_core_news_md", disable=["parser", "lemmatizer", "morphologizer", "attribute_ruler"])
    name = f"spaCy {spacy.__version__} / de_core_news_md"

    def run(lines):
        out = []
        for doc in nlp.pipe(lines, batch_size=256):
            out.append({e.label_ for e in doc.ents})
        return out
    return name, run


def ner_hf(model_id):
    from transformers import pipeline
    import torch
    torch.set_num_threads(os.cpu_count() or 4)
    nlp = pipeline("token-classification", model=model_id, aggregation_strategy="simple", device=-1)
    name = f"Transformer {model_id}"

    def run(lines):
        out = []
        for i in range(0, len(lines), 64):
            for ents in nlp(lines[i:i + 64]):
                out.append({e["entity_group"] for e in ents})
        return out
    return name, run


def norm(labels):
    """Vereinheitlicht Labels verschiedener Modelle auf PER/LOC/ORG/MISC."""
    m = {"PER": "PER", "PERSON": "PER", "LOC": "LOC", "GPE": "LOC", "ORG": "ORG", "MISC": "MISC"}
    return {m.get(l, l) for l in labels}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--engine", choices=["spacy", "hf"], required=True)
    ap.add_argument("--hf-model", default=HF_DEFAULT)
    ap.add_argument("--pruefstand", default="../pii-pruefstand")
    ap.add_argument("--site", default="..")
    ap.add_argument("--mo-dir", default="/usr/share/locale/de/LC_MESSAGES")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()

    sys.path.insert(0, os.path.abspath(a.pruefstand))
    from pruefstand.generator import generate
    from pruefstand.detectors import detect_referenz

    docs = generate(N_DOCS, seed=SEED_DOCS)
    lines = [l for d in docs for l in segments(d, detect_referenz)]
    real_tr, real_te = load_real(a.mo_dir, a.site)
    real = real_tr + real_te

    name, run = ner_spacy() if a.engine == "spacy" else ner_hf(a.hf_model)
    run(["Aufwärmen."])                                   # Modell laden, bevor die Zeit läuft
    t0 = time.perf_counter()
    ents = [norm(e) for e in run([l[0] for l in lines])]
    t_lines = time.perf_counter() - t0
    ents_real = [norm(e) for e in run(real)]

    y = [l[1] for l in lines]
    g = [l[2] for l in lines]
    rule = np.array([l[3] for l in lines])
    rule_real = np.array([bool(detect_referenz(s)) for s in real])
    per = np.array(["PER" in e for e in ents])
    per_loc = np.array([bool({"PER", "LOC"} & e) for e in ents])
    per_r = np.array(["PER" in e for e in ents_real])
    per_loc_r = np.array([bool({"PER", "LOC"} & e) for e in ents_real])

    variants = {
        "regeln": (rule, rule_real),
        "ner_per": (per, per_r),
        "ner_per_loc": (per_loc, per_loc_r),
        "regeln_oder_ner_per": (rule | per, rule_real | per_r),
        "regeln_oder_ner_per_loc": (rule | per_loc, rule_real | per_loc_r),
    }
    res = {"engine": name, "zeilen": len(lines), "echte_saetze": len(real),
           "ms_pro_zeile": t_lines / len(lines) * 1e3, "ergebnisse": {}}
    # Programmmeldungen enthalten Platzhalter wie %s, die manche Modelle für Namen halten.
    # Deshalb wird die Fehlalarmrate zusätzlich ohne solche Sätze ausgewiesen.
    no_ph = np.array(["%" not in s for s in real])
    res["echte_saetze_ohne_platzhalter"] = int(no_ph.sum())
    for k, (p, pr) in variants.items():
        r = rates(p, y, g)
        r["fehlalarme_echte_saetze"] = float(np.mean(pr))
        r["fehlalarme_echte_saetze_ohne_platzhalter"] = float(np.mean(pr[no_ph]))
        res["ergebnisse"][k] = r
    res["beispiele_fehlalarm_echt_ohne_platzhalter"] = [s for s, f, ok in zip(real, per_loc_r, no_ph) if f and ok][:10]

    # Personen-Lecks der Regeln: wie viele davon fängt die NER?
    pers_missed = [i for i, l in enumerate(lines) if "PERSON" in l[2] and not l[3]]
    res["personen_lecks_der_regeln"] = len(pers_missed)
    res["davon_von_ner_gefunden"] = int(sum(per[i] for i in pers_missed))
    # Beispiele
    res["beispiele_ner_findet_was_regeln_verpassen"] = [lines[i][0] for i in pers_missed if per[i]][:6]
    res["beispiele_ner_verpasst_person"] = [lines[i][0] for i in pers_missed if not per[i]][:6]
    fa_syn = Counter(lines[i][0][:60] for i in range(len(lines)) if per[i] and not lines[i][1])
    res["beispiele_fehlalarm_dokumente"] = [x for x, _ in fa_syn.most_common(6)]
    res["beispiele_fehlalarm_echt"] = [s for s, f in zip(real, per_loc_r) if f][:10]
    res["label_verteilung_dokumente"] = dict(Counter(l for e in ents for l in e).most_common())

    print(json.dumps({k: {kk: (round(vv, 4) if isinstance(vv, float) else vv) for kk, vv in v.items()
                          if kk != "verpasste_angaben"} for k, v in res["ergebnisse"].items()}, indent=1))
    for k in ("engine", "ms_pro_zeile", "personen_lecks_der_regeln", "davon_von_ner_gefunden",
              "beispiele_ner_findet_was_regeln_verpassen", "beispiele_ner_verpasst_person",
              "beispiele_fehlalarm_dokumente", "beispiele_fehlalarm_echt",
              "beispiele_fehlalarm_echt_ohne_platzhalter", "echte_saetze_ohne_platzhalter",
              "label_verteilung_dokumente"):
        print(k, ":", res[k])
    for k, v in res["ergebnisse"].items():
        print(k, "verpasst:", v["verpasste_angaben"])

    out = a.out or f"ergebnisse/m7_ner_{a.engine}.json"
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    print("geschrieben:", out)


if __name__ == "__main__":
    main()
