"""Lädt deutsche Bezeichnungen für Arzneimittel und Krankheiten aus Wikidata (Lizenz CC0).

  Arzneimittel = Einträge mit ATC-Code (Eigenschaft P267)
  Krankheiten  = Einträge mit ICD-10-Code (Eigenschaft P494)

Jeweils das deutsche Label und die deutschen Alternativbezeichnungen. Die Listen sind unabhängig vom
Datenschutz-Prüfstand entstanden und wurden nicht an dessen Testdaten angepasst.

Aufruf:  python fetch_wikidata.py   -> schreibt daten/wikidata_arzneimittel_de.txt und daten/wikidata_krankheiten_de.txt
"""
from __future__ import annotations

import json
import os
import time
import urllib.parse
import urllib.request

ENDPOINT = "https://query.wikidata.org/sparql"
UA = "homomorphic-lab-research/0.1 (Forschungsskript; Python urllib)"

QUERY = """
SELECT DISTINCT ?label WHERE {
  ?item wdt:%s ?code .
  ?item %s ?label .
  FILTER(LANG(?label) = "de")
}
"""


def _run(query: str) -> set[str]:
    body = urllib.parse.urlencode({"query": query}).encode()
    for attempt in range(3):
        req = urllib.request.Request(ENDPOINT, data=body, headers={
            "User-Agent": UA, "Accept": "application/sparql-results+json",
            "Content-Type": "application/x-www-form-urlencoded"})
        try:
            with urllib.request.urlopen(req, timeout=180) as r:
                data = json.loads(r.read().decode("utf-8"))
            return {b["label"]["value"].strip() for b in data["results"]["bindings"]}
        except (json.JSONDecodeError, OSError) as e:      # abgeschnittene Antwort oder Zeitüberschreitung
            print("  erneuter Versuch:", type(e).__name__)
            time.sleep(5 * (attempt + 1))
    raise RuntimeError("Wikidata-Abfrage mehrfach gescheitert")


def fetch(prop: str) -> list[str]:
    labels = set()
    for pred in ("rdfs:label", "skos:altLabel"):
        labels |= _run(QUERY % (prop, pred))
        time.sleep(2)
    return sorted(l for l in labels if l)


def main():
    os.makedirs("daten", exist_ok=True)
    for prop, name in (("P267", "arzneimittel"), ("P494", "krankheiten")):
        labels = fetch(prop)
        path = f"daten/wikidata_{name}_de.txt"
        with open(path, "w", encoding="utf-8") as f:
            f.write(f"# Quelle: Wikidata (CC0), Eigenschaft {prop}, deutsche Labels und Alternativbezeichnungen\n")
            f.write(f"# Abgerufen: {time.strftime('%Y-%m-%d')}\n")
            f.write("\n".join(labels) + "\n")
        print(path, len(labels))
        time.sleep(2)


if __name__ == "__main__":
    main()
