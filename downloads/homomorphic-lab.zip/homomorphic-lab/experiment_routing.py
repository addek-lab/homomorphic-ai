"""M5: Verschlüsseltes Routing "sensibel / unkritisch" auf Zeilen deutscher Dokumente.

Idee: Bevor ein Text an eine KI geht, entscheidet ein Klassifikator für jede Zeile, ob sie
Personendaten enthält. Unkritische Zeilen dürften weiter, sensible bleiben zurück oder werden
maskiert. Der Klassifikator läuft verschlüsselt: Der Betreiber des Modells sieht die Zeile nicht.

Verglichen werden:
  - der lineare Klassifikator (Klartext und verschlüsselt mit OpenFHE/CKKS)
  - der Referenzfilter des Datenschutz-Prüfstands (Regeln mit Prüfsummen, kein Training)

Zwei Prüfungen:
  A  bekannte Formate: Training und Test aus denselben Dokumentarten (Aufteilung nach Dokumenten)
  B  unbekannte Formate: jeweils eine Dokumentart fehlt im Training komplett und wird getestet

Wichtigste Kennzahl ist die Leckrate: Anteil der sensiblen Zeilen, die als unkritisch durchgehen.

Aufruf:  python experiment_routing.py --pruefstand ../pii-pruefstand [--out ergebnisse/m5_routing.json]
"""
from __future__ import annotations

import argparse
import json
import os
import re
import statistics as st
import sys
import time
from collections import Counter

import numpy as np

SEED_DOCS, N_DOCS = 11, 1200
TARGET_RECALL = 0.99


def digits_to_zero(s: str) -> str:
    return re.sub(r"\d", "0", s)


def vectorizer():
    from sklearn.feature_extraction.text import HashingVectorizer
    return HashingVectorizer(analyzer="char_wb", ngram_range=(2, 4), n_features=4096,
                             alternate_sign=False, norm="l2", lowercase=False,
                             preprocessor=digits_to_zero)


def segments(doc, detect=None):
    """Zerlegt ein Dokument in Zeilen. Liefert (text, sensibel, gold_labels, referenz_markiert, art)."""
    det = detect(doc.text) if detect else []
    out, pos = [], 0
    for line in doc.text.split("\n"):
        s, e = pos, pos + len(line)
        pos = e + 1
        if not line.strip():
            continue
        gold = [g.label for g in doc.spans if g.start < e and g.end > s]
        ref = any(d.start < e and d.end > s for d in det)
        out.append((line, bool(gold), gold, ref, doc.kind))
    return out


def rates(pred, y, gold_labels):
    pred, y = np.asarray(pred, bool), np.asarray(y, bool)
    n_s, n_u = int(y.sum()), int((~y).sum())
    missed = Counter(l for p, t, g in zip(pred, y, gold_labels) if t and not p for l in set(g))
    return {
        "zeilen_sensibel": n_s, "zeilen_unkritisch": n_u,
        "leckrate": float((~pred & y).sum() / n_s) if n_s else None,
        "fehlalarmrate": float((pred & ~y).sum() / n_u) if n_u else None,
        "durchgelassen_unkritisch": float((~pred & ~y).sum() / n_u) if n_u else None,
        "verpasste_angaben": dict(missed.most_common()),
    }


def fit(lines_train, rng_seed=0):
    """Trainiert den Klassifikator und stellt die Schwelle auf >= 99 % Recall (Validierung) ein."""
    from sklearn.linear_model import LogisticRegression
    vec = vectorizer()
    X = vec.transform([l[0] for l in lines_train])
    y = np.array([l[1] for l in lines_train])
    rng = np.random.default_rng(rng_seed)
    idx = rng.permutation(len(y))
    cut = int(0.8 * len(y))
    tr, va = idx[:cut], idx[cut:]
    m = LogisticRegression(C=10.0, class_weight="balanced", max_iter=3000).fit(X[tr], y[tr])
    s_va = m.decision_function(X[va])
    sens = np.sort(s_va[y[va]])
    k = int(np.floor((1 - TARGET_RECALL) * len(sens)))
    thr = float(sens[k]) - 1e-9 if len(sens) else 0.0
    thr = min(thr, 0.0)                          # nie strenger als die Standardschwelle
    m = LogisticRegression(C=10.0, class_weight="balanced", max_iter=3000).fit(X, y)
    return vec, m, thr


def evaluate(vec, m, thr, lines):
    X = vec.transform([l[0] for l in lines])
    y = [l[1] for l in lines]
    g = [l[2] for l in lines]
    s = m.decision_function(X)
    return {
        "klassifikator_standard": rates(s > 0, y, g),
        "klassifikator_eingestellt": rates(s > thr, y, g),
        "referenzfilter": rates([l[3] for l in lines], y, g),
    }, X, s


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pruefstand", default="../pii-pruefstand")
    ap.add_argument("--out", default="ergebnisse/m5_routing.json")
    ap.add_argument("--n-enc", type=int, default=300, help="Zahl der Zeilen für den verschlüsselten Lauf")
    a = ap.parse_args()

    sys.path.insert(0, os.path.abspath(a.pruefstand))
    from pruefstand.generator import generate
    from pruefstand.detectors import detect_referenz

    docs = generate(N_DOCS, seed=SEED_DOCS)
    per_doc = [segments(d, detect_referenz) for d in docs]
    kinds = sorted({d.kind for d in docs})
    res = {"daten": {"dokumente": N_DOCS, "seed": SEED_DOCS, "dokumentarten": kinds,
                     "zeilen": sum(len(p) for p in per_doc),
                     "zeilen_sensibel": sum(l[1] for p in per_doc for l in p)},
           "ziel_recall_validierung": TARGET_RECALL}
    print(res["daten"])

    # ---- A: bekannte Formate ------------------------------------------------------------
    rng = np.random.default_rng(1)
    order = rng.permutation(len(docs))
    cut = int(0.7 * len(docs))
    train = [l for i in order[:cut] for l in per_doc[i]]
    test = [l for i in order[cut:] for l in per_doc[i]]
    vec, model, thr = fit(train)
    a_res, X_test, s_test = evaluate(vec, model, thr, test)
    a_res["schwelle"] = thr
    res["A_bekannte_formate"] = a_res
    print("A:", json.dumps({k: {kk: vv for kk, vv in v.items() if kk != "verpasste_angaben"}
                             for k, v in a_res.items() if isinstance(v, dict)}, indent=1))

    # ---- verschlüsselt (auf A) ----------------------------------------------------------
    from hlab.engine import CKKSSession
    from hlab.linear import EncryptedLinearModel
    n = min(a.n_enc, len(test))
    session = CKKSSession(depth=2, slots=4096)
    enc = EncryptedLinearModel.from_sklearn(model, session=session)
    Xd = X_test[:n].toarray()
    agree, errs, times = 0, [], []
    for i in range(n):
        scores, t = enc.predict_row(Xd[i])
        errs.append(abs(scores[0] - s_test[i]))
        agree += int((scores[0] > thr) == (s_test[i] > thr))
        times.append(t.total())
    t0 = time.perf_counter()
    for i in range(n):
        model.decision_function(X_test[i])
    plain = (time.perf_counter() - t0) / n
    res["verschluesselt"] = {"zeilen": n, "gleiche_entscheidung": agree, "max_abweichung": float(max(errs)),
                             "ms_pro_zeile_median": float(st.median(times)) * 1e3,
                             "ms_pro_zeile_klartext": plain * 1e3,
                             "ringdimension": int(session.ring_dim), "chiffretext_bytes": int(session.size_bytes(enc.encrypt_input(Xd[0])))}
    print("verschlüsselt:", res["verschluesselt"])

    # ---- B: unbekannte Formate (eine Dokumentart fehlt im Training) ---------------------
    b = {}
    pooled = {"klassifikator_standard": ([], [], []), "klassifikator_eingestellt": ([], [], []),
              "referenzfilter": ([], [], [])}
    for k in kinds:
        tr = [l for p in per_doc for l in p if l[4] != k]
        te = [l for p in per_doc for l in p if l[4] == k]
        v, m, th = fit(tr)
        r, Xk, sk = evaluate(v, m, th, te)
        b[k] = r
        b[k]["schwelle"] = th
        for name, pred in (("klassifikator_standard", sk > 0), ("klassifikator_eingestellt", sk > th),
                           ("referenzfilter", [l[3] for l in te])):
            pooled[name][0].extend(pred); pooled[name][1].extend(l[1] for l in te); pooled[name][2].extend(l[2] for l in te)
        print(f"B {k}: Schwelle {th:.2f} | Klassifikator std Leck {r['klassifikator_standard']['leckrate']:.3f} "
              f"FA {r['klassifikator_standard']['fehlalarmrate']:.3f} | eingestellt Leck "
              f"{r['klassifikator_eingestellt']['leckrate']:.3f} FA {r['klassifikator_eingestellt']['fehlalarmrate']:.3f} | "
              f"Referenz Leck {r['referenzfilter']['leckrate']:.3f} FA {r['referenzfilter']['fehlalarmrate']:.3f}")
    res["B_unbekannte_formate"] = {"je_art": b,
                                   "gesamt": {n_: rates(*pooled[n_]) for n_ in pooled}}
    print("B gesamt:", json.dumps({k: {kk: vv for kk, vv in v.items()} for k, v in res["B_unbekannte_formate"]["gesamt"].items()}, indent=1, ensure_ascii=False))

    # Beispiele verpasster Zeilen (B, Klassifikator) für die Auswertung
    ex = []
    for k in kinds:
        tr = [l for p in per_doc for l in p if l[4] != k]
        te = [l for p in per_doc for l in p if l[4] == k]
        v, m, th = fit(tr)
        s = m.decision_function(v.transform([l[0] for l in te]))
        ex += [{"art": k, "zeile": l[0], "angaben": l[2]} for l, sc in zip(te, s) if l[1] and sc <= th][:3]
    res["B_beispiele_verpasst"] = ex

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    print("geschrieben:", a.out)


if __name__ == "__main__":
    main()
