"""Verschlüsselte Inferenz für lineare Modelle (z. B. scikit-learn LogisticRegression).

Ablauf (Rollen wie im echten Dienst):
  Client : verschlüsselt den Merkmalsvektor x
  Server : rechnet <w, x> + b auf dem Chiffretext (Gewichte liegen im Klartext vor)
  Client : entschlüsselt das Ergebnis (und wendet bei Bedarf die Sigmoid-Funktion an)

Der Server sieht dabei weder x noch das Ergebnis.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np

from .engine import CKKSSession, next_pow2


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def fit_sigmoid_poly(degree: int = 15, bound: float = 8.0):
    """Polynom-Näherung g(u) ≈ sigmoid(bound * u) für u in [-1, 1].

    Chiffretext-Rechnung kennt nur + und *, also muss die Sigmoid-Funktion durch ein
    Polynom ersetzt werden. Damit die Zwischenwerte klein bleiben, wird der Rohwert z vorher
    durch `bound` geteilt (u = z / bound); das steckt schon in den Gewichten.
    Außerhalb von [-bound, bound] ist die Näherung unbrauchbar: Polynome explodieren dort.
    Zurück kommen die Koeffizienten c0..cN (aufsteigend).
    """
    us = np.linspace(-1.0, 1.0, 4001)
    cheb = np.polynomial.Chebyshev.fit(us, sigmoid(bound * us), degree)
    return np.polynomial.polynomial.polyfit(us, cheb(us), degree)


@dataclass
class Timing:
    encrypt: float = 0.0
    evaluate: float = 0.0
    decrypt: float = 0.0
    ct_bytes: int = 0

    def total(self) -> float:
        return self.encrypt + self.evaluate + self.decrypt


@dataclass
class EncryptedLinearModel:
    """Macht ein scikit-learn-Modell mit `coef_` und `intercept_` verschlüsselt nutzbar."""

    weights: np.ndarray          # (n_klassen_oder_1, n_merkmale)
    bias: np.ndarray             # (n_klassen_oder_1,)
    session: CKKSSession
    encrypted_sigmoid: bool = False
    sigmoid_bound: float = 8.0            # Rohwerte außerhalb ±bound werden falsch bewertet
    _w_pts: list = field(default_factory=list, repr=False)
    _bias_used: np.ndarray | None = field(default=None, repr=False)
    _poly: np.ndarray | None = field(default=None, repr=False)

    @classmethod
    def from_sklearn(cls, model, session: CKKSSession | None = None, encrypted_sigmoid: bool = False,
                     sigmoid_bound: float = 8.0):
        if not hasattr(model, "coef_") or not hasattr(model, "intercept_"):
            raise ValueError(
                "Das Modell braucht die Attribute coef_ und intercept_ "
                "(LogisticRegression, LinearRegression, Ridge, LinearSVC, ...)."
            )
        w = np.atleast_2d(np.asarray(model.coef_, dtype=float))
        b = np.atleast_1d(np.asarray(model.intercept_, dtype=float))
        n = w.shape[1]
        if session is None:
            # Tiefe: 1 Multiplikation für <w,x>, dazu Polynomgrad 15 (braucht 5 Stufen) für die Sigmoid-Funktion
            session = CKKSSession(depth=8 if encrypted_sigmoid else 2, slots=next_pow2(n))
        if session.slots < n:
            raise ValueError(f"Session hat {session.slots} Slots, das Modell {n} Merkmale.")
        obj = cls(weights=w, bias=b, session=session, encrypted_sigmoid=encrypted_sigmoid,
                  sigmoid_bound=float(sigmoid_bound))
        obj._prepare()
        return obj

    def _prepare(self):
        s = self.session
        w, b = self.weights, self.bias
        if self.encrypted_sigmoid:
            if len(w) != 1:
                raise ValueError("Verschlüsselte Sigmoid-Funktion nur bei binärer Klassifikation.")
            w, b = w / self.sigmoid_bound, b / self.sigmoid_bound    # u = z / bound, siehe fit_sigmoid_poly
            self._poly = fit_sigmoid_poly(bound=self.sigmoid_bound)
        pad = s.slots - w.shape[1]
        self._w_pts = [s.encode(np.pad(row, (0, pad))) for row in w]
        self._bias_used = b

    # ---- Client-Seite -----------------------------------------------------------
    def encrypt_input(self, x):
        pad = self.session.slots - len(x)
        return self.session.encrypt(np.pad(np.asarray(x, dtype=float), (0, pad)))

    # ---- Server-Seite (kennt nur Chiffretext) -----------------------------------
    def evaluate(self, ct_x):
        s = self.session
        outs = []
        for w_pt, b in zip(self._w_pts, self._bias_used):
            ct = s.sum_slots(s.mul(ct_x, w_pt))      # <w, x> im ersten Slot
            ct = s.add(ct, float(b))
            if self.encrypted_sigmoid:
                ct = s.poly(ct, self._poly)
            outs.append(ct)
        return outs

    # ---- Komfortfunktion: ein ganzer Durchlauf mit Zeitmessung --------------------
    def predict_row(self, x):
        s, t = self.session, Timing()

        t0 = time.perf_counter()
        ct_x = self.encrypt_input(x)
        t.encrypt = time.perf_counter() - t0
        t.ct_bytes = s.size_bytes(ct_x)

        t0 = time.perf_counter()
        outs = self.evaluate(ct_x)
        t.evaluate = time.perf_counter() - t0

        t0 = time.perf_counter()
        scores = np.array([s.decrypt(o, 1)[0] for o in outs])
        t.decrypt = time.perf_counter() - t0
        return scores, t

    def predict_class(self, x):
        """Gibt (Klassenindex, Rohwerte, Timing) zurück."""
        scores, t = self.predict_row(x)
        if len(scores) == 1:
            threshold = 0.5 if self.encrypted_sigmoid else 0.0
            return int(scores[0] > threshold), scores, t
        return int(np.argmax(scores)), scores, t
