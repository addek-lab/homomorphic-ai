"""Dünne Hülle um OpenFHE (CKKS-Verfahren) für Experimente.

CKKS rechnet näherungsweise mit reellen Zahlen und eignet sich deshalb gut für
Machine Learning. Eine Session bündelt Parameter, Schlüssel und die wichtigsten
Operationen, damit die Experimente kurz und lesbar bleiben.
"""
from __future__ import annotations

import os
import tempfile

try:
    import openfhe as of
except ImportError as exc:  # pragma: no cover - nur Hilfetext
    raise SystemExit(
        "OpenFHE ist nicht installiert (oder läuft auf dieser Plattform nicht).\n"
        "Das pip-Paket 'openfhe' gibt es nur für Linux auf x86_64 mit Python 3.12.\n"
        "Nutze Docker oder WSL2, siehe README.md.\n"
        f"Originalfehler: {exc}"
    )


def next_pow2(n: int) -> int:
    p = 1
    while p < n:
        p *= 2
    return p


class CKKSSession:
    """Kryptokontext + Schlüsselpaar + Hilfsfunktionen.

    depth      -- wie viele Multiplikationen hintereinander möglich sind
    scale_bits -- Größe des Skalierungsfaktors (bestimmt die Genauigkeit)
    slots      -- wie viele Zahlen in einen Chiffretext gepackt werden (Zweierpotenz)
    ring_dim   -- optional: Ringdimension erzwingen (0 = OpenFHE wählt sie automatisch)
    """

    def __init__(self, depth: int = 4, scale_bits: int = 50, slots: int = 32, ring_dim: int = 0):
        self.depth = depth
        self.scale_bits = scale_bits
        self.slots = next_pow2(slots)

        params = of.CCParamsCKKSRNS()
        params.SetMultiplicativeDepth(depth)
        params.SetScalingModSize(scale_bits)
        params.SetBatchSize(self.slots)
        if ring_dim:
            params.SetRingDim(ring_dim)

        self.cc = of.GenCryptoContext(params)
        self.cc.Enable(of.PKESchemeFeature.PKE)
        self.cc.Enable(of.PKESchemeFeature.KEYSWITCH)
        self.cc.Enable(of.PKESchemeFeature.LEVELEDSHE)
        self.cc.Enable(of.PKESchemeFeature.ADVANCEDSHE)

        self.keys = self.cc.KeyGen()
        self.cc.EvalMultKeyGen(self.keys.secretKey)
        self.cc.EvalSumKeyGen(self.keys.secretKey)

    # ---- Zugriff auf Kennzahlen ------------------------------------------------
    @property
    def ring_dim(self) -> int:
        return self.cc.GetRingDimension()

    # ---- Ver- und Entschlüsseln --------------------------------------------------
    def encode(self, values):
        """Reelle Zahlen zu einem (noch unverschlüsselten) Plaintext packen."""
        return self.cc.MakeCKKSPackedPlaintext(list(map(float, values)))

    def encrypt(self, values):
        return self.cc.Encrypt(self.keys.publicKey, self.encode(values))

    def decrypt(self, ct, n: int | None = None):
        pt = self.cc.Decrypt(ct, self.keys.secretKey)
        n = n or self.slots
        pt.SetLength(n)
        return list(pt.GetRealPackedValue())[:n]

    # ---- Rechnen auf Chiffretext -------------------------------------------------
    def add(self, a, b):
        return self.cc.EvalAdd(a, b)

    def sub(self, a, b):
        return self.cc.EvalSub(a, b)

    def mul(self, a, b):
        """Multiplikation (Chiffretext * Chiffretext, Plaintext oder Zahl)."""
        return self.cc.EvalMult(a, b)

    def rotate(self, ct, k: int):
        """Slots zyklisch verschieben (braucht vorher einen passenden Rotationsschlüssel)."""
        return self.cc.EvalRotate(ct, k)

    def make_rotation_keys(self, shifts):
        self.cc.EvalAtIndexKeyGen(self.keys.secretKey, list(shifts))

    def sum_slots(self, ct, count: int | None = None):
        """Summiert die ersten `count` Slots; das Ergebnis steht im ersten Slot."""
        return self.cc.EvalSum(ct, count or self.slots)

    def poly(self, ct, coeffs):
        """Polynom p(x) = c0 + c1*x + c2*x^2 + ... auf Chiffretext auswerten."""
        return self.cc.EvalPoly(ct, list(map(float, coeffs)))

    def level(self, ct) -> int:
        """Wie viele Multiplikationsstufen sind bereits verbraucht."""
        return ct.GetLevel()

    # ---- Größen ------------------------------------------------------------------
    def size_bytes(self, obj) -> int:
        """Größe eines Objekts in serialisierter Form (z. B. Chiffretext)."""
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "obj.bin")
            ok = of.SerializeToFile(path, obj, of.BINARY)
            if not ok:
                raise RuntimeError("Serialisierung fehlgeschlagen")
            return os.path.getsize(path)
