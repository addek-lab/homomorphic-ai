"""Homomorphic Lab: kleine Experimente mit verschlüsselter KI-Inferenz (OpenFHE / CKKS)."""
__version__ = "0.1.0"
