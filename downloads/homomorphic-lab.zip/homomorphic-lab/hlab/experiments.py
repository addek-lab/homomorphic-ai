"""Die Experimente des Homomorphic Lab. Jedes gibt verständliche Ausgaben auf Deutsch aus."""
from __future__ import annotations

import time

import numpy as np

from .engine import CKKSSession
from .linear import EncryptedLinearModel, sigmoid


def _head(title: str):
    print("\n" + "=" * 70)
    print(title)
    print("=" * 70)


def _ms(seconds: float) -> str:
    return f"{seconds * 1000:,.1f} ms".replace(",", ".")


def _kb(n: int) -> str:
    return f"{n / 1024:,.0f} KB".replace(",", ".")


# --------------------------------------------------------------------------- 1
def exp_hello():
    _head("Experiment 1: Hallo, verschlüsselte Welt")
    s = CKKSSession(depth=2, slots=8)
    print(f"Kontext erzeugt (Ringdimension {s.ring_dim}, 8 Slots, Tiefe 2)\n")

    a = [1.0, 2.0, 3.0, 4.0]
    b = [0.5, 0.5, 2.0, -1.0]
    ca, cb = s.encrypt(a), s.encrypt(b)
    print("Klartext a            :", a)
    print("Klartext b            :", b)
    print("Chiffretext von a     : (Zufallsdaten, nicht lesbar), Größe", _kb(s.size_bytes(ca)))

    print("\nRechnen, ohne zu entschlüsseln:")
    tests = {
        "a + b": (s.add(ca, cb), np.add(a, b)),
        "a * b": (s.mul(ca, cb), np.multiply(a, b)),
        "a * 3": (s.mul(ca, 3.0), np.multiply(a, 3.0)),
    }
    s.make_rotation_keys([1])
    tests["a um 1 Slot verschoben"] = (s.rotate(ca, 1), np.roll(np.pad(a, (0, 4)), -1)[:4])

    for name, (ct, expected) in tests.items():
        got = s.decrypt(ct, 4)
        err = np.max(np.abs(np.array(got) - expected))
        print(f"  {name:<24} -> {(np.round(got, 6) + 0.0).tolist()}   (max. Fehler {err:.2e})")
    print("\nDie Ergebnisse sind nicht exakt: CKKS rechnet näherungsweise, der Fehler ist winzig.")


# --------------------------------------------------------------------------- 2
def exp_depth():
    _head("Experiment 2: Rauschen und Rechentiefe")
    depth = 4
    s = CKKSSession(depth=depth, slots=4)
    x = np.array([1.5, 0.9, 1.1, 0.8])
    cx = s.encrypt(x)
    ct = cx
    print(f"Wir multiplizieren x wiederholt mit sich selbst. Erlaubte Tiefe: {depth}.\n")
    print(f"{'Schritt':<9}{'Rechnung':<12}{'verbrauchte Stufen':<20}{'max. Fehler'}")
    for i in range(2, depth + 3):
        try:
            ct = s.mul(ct, cx)
            got = np.array(s.decrypt(ct, 4))     # OpenFHE merkt "zu tief" oft erst beim Entschlüsseln
        except Exception:
            print(f"{i - 1:<9}x^{i:<10}{s.level(ct):<20}Entschlüsselung scheitert (Näherungsfehler zu hoch)")
            print("\nDas Rauschbudget ist aufgebraucht: Mehr als 4 Multiplikationen hintereinander liefern")
            print("Unsinn. In der Praxis plant man die Tiefe im Voraus oder erneuert das Budget per")
            print("Bootstrapping (teuer).")
            return
        err = np.max(np.abs(got - x ** i))
        print(f"{i - 1:<9}x^{i:<10}{s.level(ct):<20}{err:.2e}")


# --------------------------------------------------------------------------- 3
def _train_example():
    from sklearn.datasets import load_breast_cancer
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler

    data = load_breast_cancer()
    Xtr, Xte, ytr, yte = train_test_split(data.data, data.target, test_size=0.2, random_state=0, stratify=data.target)
    scaler = StandardScaler().fit(Xtr)
    model = LogisticRegression(max_iter=2000).fit(scaler.transform(Xtr), ytr)
    return model, scaler.transform(Xte), yte


def _compare(model, X, y, n, use_sigmoid, label):
    n = min(n, len(X))
    bound = 8.0
    if use_sigmoid:
        # Die Polynom-Näherung gilt nur in einem festen Bereich. Hier wird er aus den Daten bestimmt;
        # in echt müsste man ihn vorab festlegen, ohne die Daten zu kennen (das ist die Schwäche).
        z = np.abs(model.decision_function(X[:n]))
        bound = max(4.0, float(np.ceil(1.15 * z.max())))
    enc = EncryptedLinearModel.from_sklearn(model, encrypted_sigmoid=use_sigmoid, sigmoid_bound=bound)
    print(f"{label}: {X.shape[1]} Merkmale, Ringdimension {enc.session.ring_dim}, "
          f"{'mit' if use_sigmoid else 'ohne'} Sigmoid unter Verschlüsselung")
    if use_sigmoid:
        print(f"Polynom-Näherung (Grad 15) gilt für Rohwerte im Bereich ±{bound:g}")
    print()

    plain_pred = model.predict(X[:n])
    agree, correct, errs, times, size = 0, 0, [], [], 0
    for i in range(n):
        cls, scores, t = enc.predict_class(X[i])
        ref = model.decision_function(X[i:i + 1])[0]
        if len(scores) == 1:
            ref = sigmoid(ref) if use_sigmoid else ref
            errs.append(abs(scores[0] - ref))
        else:
            errs.append(np.max(np.abs(scores - ref)))
        pred = model.classes_[cls]
        agree += int(pred == plain_pred[i])
        correct += int(y is not None and pred == y[i])
        times.append(t)
        size = t.ct_bytes

    print(f"Übereinstimmung mit Klartext-Vorhersage : {agree}/{n}")
    if y is not None:
        print(f"Treffer gegen die echten Labels          : {correct}/{n}")
    print(f"Größter Abstand der Zahlenwerte          : {max(errs):.2e}")
    if use_sigmoid:
        print("  (Dieser Abstand kommt von der Polynom-Näherung der Sigmoid-Funktion, nicht von der")
        print("   Verschlüsselung. Ein größerer Wertebereich bedeutet eine gröbere Näherung.)")
    print(f"Ø Verschlüsseln / Rechnen / Entschlüsseln: "
          f"{_ms(np.mean([t.encrypt for t in times]))} / {_ms(np.mean([t.evaluate for t in times]))} / "
          f"{_ms(np.mean([t.decrypt for t in times]))}")
    print(f"Größe eines Chiffretexts                 : {_kb(size)} "
          f"(Klartext: {X.shape[1] * 8} Byte)")

    t0 = time.perf_counter()
    model.predict(X[:n])
    print(f"Zum Vergleich: Klartext-Vorhersage ({n} Zeilen) {_ms(time.perf_counter() - t0)} gesamt")


def exp_logreg(n: int = 20, use_sigmoid: bool = False):
    _head("Experiment 3: Verschlüsselte Krebs-Diagnose mit einem normalen KI-Modell")
    print("Ein ganz gewöhnliches scikit-learn-Modell (logistische Regression) sagt voraus,")
    print("ob ein Tumor gut- oder bösartig ist. Der Server sieht die Messwerte nie.\n")
    model, X, y = _train_example()
    _compare(model, X, y, n, use_sigmoid, "Brustkrebs-Datensatz")


# --------------------------------------------------------------------------- 4
def exp_params():
    _head("Experiment 4: Parameter und ihre Kosten")
    print("Mehr Rechentiefe und Genauigkeit bedeuten größere Ringe, größere Chiffretexte")
    print("und langsamere Operationen.\n")
    plain = 32 * 8
    print(f"{'Tiefe':<7}{'Skalierung':<12}{'Ringdim.':<10}{'Setup':<12}{'Verschl.':<12}{'Chiffretext':<14}{'Aufblähung'}")
    for depth, bits in [(1, 40), (2, 50), (4, 50), (8, 50), (12, 59)]:
        t0 = time.perf_counter()
        s = CKKSSession(depth=depth, scale_bits=bits, slots=32)
        setup = time.perf_counter() - t0
        t0 = time.perf_counter()
        ct = s.encrypt(list(range(32)))
        enc = time.perf_counter() - t0
        size = s.size_bytes(ct)
        print(f"{depth:<7}{bits:<12}{s.ring_dim:<10}{_ms(setup):<12}{_ms(enc):<12}{_kb(size):<14}{size / plain:,.0f}x".replace(",", "."))
    print("\n'Aufblähung' = Chiffretext-Größe geteilt durch die Größe der 32 Klartext-Zahlen (256 Byte).")


# --------------------------------------------------------------------------- 5
def exp_own(model_path: str, csv_path: str, n: int = 10, use_sigmoid: bool = False):
    _head("Experiment 5: Dein eigenes Modell")
    import joblib

    print("Achtung: joblib-/pickle-Dateien können beim Laden Code ausführen. Lade nur Dateien,")
    print("denen du vertraust.\n")
    model = joblib.load(model_path)
    try:
        X = np.loadtxt(csv_path, delimiter=",")
    except ValueError:
        X = np.loadtxt(csv_path, delimiter=",", skiprows=1)
    X = np.atleast_2d(X)

    if hasattr(model, "steps"):                    # Pipeline: Vorverarbeitung läuft beim Client im Klartext
        pre, final = model[:-1], model[-1]
        X = pre.transform(X)
        print(f"Pipeline erkannt: {len(model.steps) - 1} Vorverarbeitungsschritt(e) laufen beim Client im Klartext.")
    else:
        final = model
    _compare(final, X, None, n, use_sigmoid, "Eigene Daten")
